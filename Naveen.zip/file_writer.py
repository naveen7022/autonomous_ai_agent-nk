from fpdf import FPDF

def write_to_pdf(browser_data, terminal_data):
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", size=12)

    pdf.cell(200, 10, txt="Autonomous Agent Report", ln=True, align='C')

    pdf.cell(200, 10, txt="Browser Data:", ln=True, align='L')
    for line in browser_data:
        pdf.multi_cell(0, 10, txt=line)

    pdf.cell(200, 10, txt="Terminal Data:", ln=True, align='L')
    pdf.multi_cell(0, 10, txt=terminal_data)

    pdf.output("report.pdf")

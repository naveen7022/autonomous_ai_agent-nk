import subprocess

def run_terminal_command():
    result = subprocess.run(["dir"], shell=True, capture_output=True, text=True)  # use "ls" for Mac/Linux
    return result.stdout

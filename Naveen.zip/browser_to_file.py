from browser_scraper import get_ai_headlines
from file_writer import write_to_pdf

def browser_to_pdf():
    headlines = get_ai_headlines()
    write_to_pdf(headlines, "Browser data only")

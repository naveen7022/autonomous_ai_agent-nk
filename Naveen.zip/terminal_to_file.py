from terminal_runner import run_terminal_command
from file_writer import write_to_pdf

def terminal_to_pdf():
    terminal_output = run_terminal_command()
    write_to_pdf(["Terminal data only"], terminal_output)

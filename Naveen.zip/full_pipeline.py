from browser_scraper import get_ai_headlines
from terminal_runner import run_terminal_command
from file_writer import write_to_pdf

def full_pipeline():
    headlines = get_ai_headlines()
    terminal_output = run_terminal_command()
    write_to_pdf(headlines, terminal_output)

if __name__ == "__main__":
    full_pipeline()

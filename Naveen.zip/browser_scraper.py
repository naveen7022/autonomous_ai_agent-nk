from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager

def get_ai_headlines():
    driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()))
    driver.get("https://news.google.com/search?q=AI")

    headlines = driver.find_elements(By.TAG_NAME, "h3")
    results = [headline.text for headline in headlines[:5]]
    driver.quit()
    return results
